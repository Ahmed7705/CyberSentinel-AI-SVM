(function () {
  const body = document.querySelector('body');
  if (body) {
    body.classList.add('js-enabled');
  }
})();
