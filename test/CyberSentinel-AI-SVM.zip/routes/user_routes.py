"""User dashboard routes."""
from __future__ import annotations

from flask import Blueprint, flash, jsonify, redirect, render_template, request, session, url_for

from database.database import execute, fetch_all
from services import alert_service, auth_service

user_bp = Blueprint("user", __name__, url_prefix="/user")


def _require_user():
    if not session.get("user_id"):
        return redirect(url_for("auth.login"))
    return None


@user_bp.route("/dashboard", methods=["GET"])
def dashboard():
    guard = _require_user()
    if guard:
        return guard
    user_id = session["user_id"]
    alerts = alert_service.get_user_alerts(user_id, limit=10)
    activities = fetch_all(
        """
        SELECT event_type, timestamp, source_ip, device, location, risk_score
        FROM activity_logs
        WHERE user_id = %s
        ORDER BY timestamp DESC
        LIMIT 15
        """,
        (user_id,),
    )
    return render_template("user-dashboard.html", alerts=alerts, activities=activities)


@user_bp.route("/profile", methods=["GET", "POST"])
def profile():
    guard = _require_user()
    if guard:
        return guard

    user_id = session["user_id"]
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip() or None
        department = request.form.get("department", "").strip() or None
        if full_name or department:
            execute(
                "UPDATE users SET full_name = COALESCE(%s, full_name), department = COALESCE(%s, department) WHERE id = %s",
                (full_name, department, user_id),
            )
            if full_name:
                session["full_name"] = full_name
            flash("Profile updated", "success")
        else:
            flash("No changes submitted", "warning")
    user = auth_service.get_user_by_id(user_id)
    return render_template("users.html", user=user)


@user_bp.route("/api/alerts", methods=["GET"])
def alerts_json():
    guard = _require_user()
    if guard:
        return guard
    return jsonify(alert_service.get_user_alerts(session["user_id"], limit=50))
