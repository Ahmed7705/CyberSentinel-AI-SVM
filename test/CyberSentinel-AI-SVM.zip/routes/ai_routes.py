"""AI orchestration routes."""
from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request, session

from database.database import fetch_all
from ai_engine.engine import generate_alert_insight

aio_bp = Blueprint("ai", __name__, url_prefix="/ai")


def _get_engine():
    engine = current_app.extensions.get("ai_engine")
    if not engine:
        raise RuntimeError("AI engine is not initialised")
    return engine

ai_bp = Blueprint("ai", __name__, url_prefix="/ai")

@ai_bp.route("/detect", methods=["POST"])
def detect_activity():
    if not session.get("user_id"):
        return {"error": "Authentication required"}, 401
    payload = request.get_json() or {}
    payload.setdefault("user_id", session.get("user_id"))
    payload.setdefault("description", payload.get("event_type", "Manual scan"))
    engine = _get_engine()
    try:
        result = engine.analyse_activity(payload)
    except RuntimeError as exc:
        return {"error": str(exc)}, 400
    return jsonify(result.as_dict())


@ai_bp.route("/train", methods=["POST"])
def train_models():
    if session.get("role") != "admin":
        return {"error": "Admin access required"}, 403
    limit = int((request.get_json() or {}).get("limit", 500))
    engine = _get_engine()
    engine.warm_start(limit=limit)
    return {"status": "trained", "limit": limit}


@ai_bp.route("/activity-feed", methods=["GET"])
def activity_feed():
    if session.get("role") != "admin":
        return {"error": "Admin access required"}, 403
    rows = fetch_all(
        """
        SELECT user_id, event_type, source_ip, device, location, timestamp, risk_score
        FROM activity_logs
        ORDER BY timestamp DESC
        LIMIT 50
        """
    )
    return jsonify(rows)


@ai_bp.route("/interact", methods=["POST"])
def interact_with_ai():
    if session.get("role") != "admin":
        return {"error": "Admin access required"}, 403
    payload = request.get_json() or {}
    prompt = (payload.get("prompt") or "").strip()
    if not prompt:
        return {"error": "Prompt is required"}, 400
    insight = generate_alert_insight(prompt)
    if not insight:
        insight = "AI service is currently unavailable. Please try again later."
    return {"response": insight}




